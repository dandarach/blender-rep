'''Teamatical Addon'''

import bpy
from bpy.utils import (register_class, unregister_class)
from bpy.props import (StringProperty,
                       BoolProperty,
                       IntProperty,
                       FloatProperty,
                       FloatVectorProperty,
                       EnumProperty,
                       PointerProperty,
                       )
from bpy.types import (Panel,
                       Operator,
                       AddonPreferences,
                       PropertyGroup,
                       )
from teamatical_panel.teamatical.blender_addon import *


bl_info = {
    'name': 'Teamatical Tools',
    'description': 'Process CLO3D mesh and prepare for baking',
    'author': 'Teamatical',
    'version': (3, 2, 0),
    'blender': (3, 4, 0),
    'location': 'Tool tab in N-panel',
    'wiki_url': 'https://www.teamatical.com',
    'category': 'Development'
}


# ------------------------------------------------------------------------
#    Store properties in the active scene
# ------------------------------------------------------------------------

class TeamaticalPanelSettings(PropertyGroup):
    '''Teamatical Panel settings'''
    sandwich_selector:BoolProperty(
        name = 'Sandwich pattern',
        description = 'Sandwich pattern selector',
        default = False
        )

    baking_sampling:IntProperty(
        name = 'Sampling',
        description = 'Baking sampling',
        default = 1500,
        min = 1,
        max = 10000
        )

    baking_margins:IntProperty(
        name = 'Margins',
        description = 'Baking margins',
        default = 5,
        min = 0,
        max = 100
        )

# ------------------------------------------------------------------------
#    Teamatical Tools
# ------------------------------------------------------------------------

class TeamaticalPanel(bpy.types.Panel):
    '''Teamatical Panel Main Class'''
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    #bl_space_type  = 'PROPERTIES'
    bl_category = 'Teamatical'
    bl_idname = 'TEAMATICAL_PT_TOOLS'
    bl_label = 'Teamatical Tools'
    #use_pin = True
    #bl_context = 'objectmode'
    #bl_options = {'HIDE_HEADER'}
    #bl_order = 0
    #bl_description = 'sdafsdafsaddsfa'

    # this is needed to check if the operator can be executed/invoked
    # in the current context, useful for some but not for this example    
    # @classmethod
    # def poll(cls, context):
    #     #check the context here
    #     return context.object is not None

    def draw(self, context):
        layout = self.layout
        #scene = context.scene
        tmtool = context.scene.tm_tool

        row = layout.row()
        row.operator('teamatical.clean_scene', icon = 'TRASH')
        row = layout.row()
        row.operator('teamatical.import_obj', icon ='IMPORT')
        row = layout.row()
        row.operator('teamatical.reset_obj_position', icon = 'EMPTY_DATA')
        row = layout.row()
        row.operator('teamatical.move_vertices_to_groups', icon = 'MESH_DATA')

        row = layout.row()
        split = row.split(factor = 0.5)
        left_col  = split.column(align = True)
        right_col = split.column(align = True)
        left_col.alignment  = 'RIGHT'
        right_col.alignment = 'CENTER'
        left_col.operator('teamatical.move_uvs', icon = 'MESH_GRID')
        right_col.prop(tmtool, 'sandwich_selector', text = 'Sandwich')

        row = layout.row()
        row.operator('teamatical.create_shadows_image', icon = 'FILE_IMAGE')
        row = layout.row()
        row.operator('teamatical.create_material', icon = 'NODE_TEXTURE')
        row = layout.row()
        row.operator('teamatical.setup_scene', icon = 'SHADING_TEXTURE')
        row = layout.row()
        row.operator('teamatical.save_blend_file', icon = 'BLENDER')

        row = layout.split()
        row = layout.split()

        row = layout.row()
        split = row.split(factor = 0.6)
        left_col  = split.column(align = True)
        right_col = split.column(align = True)
        left_col.alignment  = 'RIGHT'
        right_col.alignment = 'CENTER'
        left_col.label(text = "Sampling")
        right_col.prop(tmtool, 'baking_sampling', text = '')

        row = layout.row()
        split = row.split(factor = 0.6)
        left_col  = split.column(align = True)
        right_col = split.column(align = True)
        left_col.alignment  = 'RIGHT'
        right_col.alignment = 'CENTER'
        left_col.label(text = "Margins")
        right_col.prop(tmtool, 'baking_margins', text = '')

        row = layout.row()
        row.operator('teamatical.bake_and_save_shadows', icon = 'RESTRICT_RENDER_OFF')
        row = layout.row()
        row.operator('teamatical.crunch_obj', icon = 'SHADERFX')
        row.enabled = False
        row = layout.row()
        #row.operator('teamatical.save_obj', icon = 'EXPORT')
        row.operator('teamatical.save_obj', icon = 'MATCLOTH')


# ------------------------------------------------------------------------
#    Registration
# ------------------------------------------------------------------------

#register, unregister = bpy.utils.register_classes_factory(classes)

classes = ( TeamaticalPanelSettings,
            TeamaticalPanel,
            CleanScene,
            ImportOBJ,
            ResetObjectPosition,
            MoveVertexesToGroupsByMaterial,
            MoveUVs,
            CreateShadowsImage,
            CreateMaterial,
            SetupScene,
            SaveBlendFile,
            BakeAndSaveShadows,
            CrunchOBJ,
            SaveOBJ
        )


def register():
    '''Register classes'''
    print('=== Teamatical Addon ===')
    for clss in classes:
        register_class(clss)

    bpy.types.Scene.tm_tool = PointerProperty(type = TeamaticalPanelSettings)


def unregister():
    '''Unregister classes'''
    for clss in reversed(classes):
        unregister_class(clss)

    del bpy.types.Scene.tm_tool

if __name__ == '__main__':
    register()
