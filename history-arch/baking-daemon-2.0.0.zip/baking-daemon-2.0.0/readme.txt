Baking Daemon v2.0.0

1. Please install Teamatical BelnerPanel add-on first.
2. Run !install-run-as-admin.cmd with administrator privileges.
