<#
    .SYNOPSIS
    Install Baking Daemon

    .DESCRIPTION
    Create sheduled tasks, setup Path to Blender.exe

    .PARAMETER

    .EXAMPLE
  
    .NOTES
    Version:        2.0.0
    Author:         Teamatical Inc.
    Creation Date:  17 oct 2023
    Modified Date:  19 jan 2023
    Link:           https://www.teamatical.com
#>

[CmdletBinding()]
Param ([string]$cmdName = "")

[Boolean]$DEBUG = $false
[string]$BAKING_FOLDER_NAME = "baking-files"

function ShowBalloonTip([String]$text = "", [String]$title = "Baking Daemon", [String]$icon = "Info", [Int]$showtime = 5000) {
    # $icon can be 'None','Info','Warning','Error'
    $global:balloon = New-Object System.Windows.Forms.NotifyIcon
    $path = (Get-Process -id $pid).Path
    $balloon.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($path)
    $balloon.BalloonTipIcon = $icon
    $balloon.BalloonTipText = $text
    $balloon.BalloonTipTitle = $title
    $balloon.Visible = $true
    $balloon.ShowBalloonTip($showTime)
}

function SelectFolder([String]$description = "Select the folder") {
    # Open select folder dialog
    $dialog = [System.Windows.Forms.FolderBrowserDialog]::new()
    $dialog.Description = $description
    $dialog.RootFolder = [System.Environment+specialfolder]::MyComputer
    $dialog.ShowNewFolderButton = $true
    $null = $dialog.ShowDialog()
    [String]$selectedFolder = $dialog.SelectedPath
    $dialog.Dispose()
    Write-Host "Selected folder: $selectedFolder"
    return $selectedFolder
}

function FindFilePath([String]$fName = "Blender.exe") {
    # Find the path to the specified file
    Write-Host "Searching file: $fName"
    [string]$fPath = Get-ChildItem -Path $env:ProgramFiles -Filter $fName -Recurse -ErrorAction SilentlyContinue -Force | % { $_.DirectoryName }
    Write-Host "Founded file path: $fPath"
    return $fPath
}

function BackupPath([String]$backupPathName = "backup-path.txt") {
    # Create a backup of the PATH variable content
    Write-Host "Backup Path path: $backupPathName"
    [System.Environment]::GetEnvironmentVariable('Path','Machine') > $backupPathName
}

function AppendToPath([String]$folderPath = "") {
    # Append path to Blender.exe to the Path system variable (Machine Path - HKLM)
    if ($folderPath -eq "")
    {
        Write-Host "WARNING: Nothing to add to Path system variable" -ForegroundColor Yellow
        return
    }

    [string]$oldPath = [System.Environment]::GetEnvironmentVariable("Path", "Machine")
    $oldPathArray = ($oldPath) -split ';'
    # Check if Path already contains path to specified folder
    if (-Not($oldPathArray -Contains $folderPath)) {
        Write-Host "Adding $folderPath to Machine Path"
        [string]$newPath = ($oldPath + ";" + $folderPath) -replace ';+',';'
        try {
            [System.Environment]::SetEnvironmentVariable("Path", $newPath, "Machine")
            $env:Path = [System.Environment]::GetEnvironmentVariable("Path","User"),[System.Environment]::GetEnvironmentVariable("Path","Machine") -join ";"
            Write-Host ""
            Write-Host "Windows paths:"
            ($env:Path).Replace(';',"`n")
            Write-Host ""
        } catch {
            Write-Host "ERROR: Can not change Path. Registry access is not allowed " -ForegroundColor Red
        }
    }
}

function CreateSheduledTasks() {
    # Create task to empty Yandex disk trash bin
#TODO: Authorization problems
<#
    Write-Host "Creating sheduled tasks..."
    $trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Friday -At 11:30pm
    [string]$argg = "-File " + $PSScriptRoot + "\empty_cloud_trash.ps1"
    $action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "$argg"
    try {
        Register-ScheduledTask -TaskName "Teamatical\Empty Yandex Disk Trash" -Trigger $trigger -Action $action -Force -Description "Empty Yandex disk trash bin" -ErrorAction Stop
    } catch {
        Write-Host "ERROR: Can not create sheduled task 'Empty Yandex Disk Trash'" -ForegroundColor Red
    }
#>

    # Create task to run Baking Daemon on Windows startup
    $trigger = New-ScheduledTaskTrigger -AtLogon #-AtStartup
    [string]$argg = "-NoExit -File " + $PSScriptRoot + "\baking_daemon.ps1"
    $action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "$argg"
    try {
        Register-ScheduledTask -TaskName "Teamatical\Start Baking Service" -Trigger $trigger -Action $action -Description "Run Baking Daemon on Windows startup" -ErrorAction Stop
    } catch {
        Write-Host "ERROR: Can not create sheduled task 'Start Baking Service'" -ForegroundColor Red
    }

<#
    # Create Test task
    # Convert datetime to yyyy-mmm-dd datetime format
    '{0:yyyy-MMM-dd}' -f $convertDate
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 1)
    $user = "NT AUTHORITY\LOCALSERVICE"
    $action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument $PSScriptRoot"\utils\test_task.ps1"
    Register-ScheduledTask -TaskName "Teamatical\Test task" -Trigger $trigger -Action $action -Description "Test task description"
#>
}


###================================================================================###
###================================================================================###
Write-Host "*** Baking Daemon Installer ***" -ForegroundColor Green
#Get-ExecutionPolicy -List
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

Write-Host "CMD name: $cmdName"
if ($cmdName -eq "") {
    Write-Host "WARNING: CMD name is Null" -ForegroundColor Yellow
}

# Check Administrator privileges
If (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "ERROR: You do not have Administrator rights" -ForegroundColor Red
    ShowBalloonTip "You do not have Administrator rights" "Baking Daemon" "Error"
    if ($DEBUG -ne $true) {
        Exit 21
    }
} else {
    Write-Host "You have Administrator rights" -ForegroundColor Yellow
    ShowBalloonTip "Installing..." "Baking Daemon" "Info"
}

# Check if there is no Blender.exe
[String]$blenderPath = FindFilePath "Blender.exe"
if ($blenderPath -eq "") {
    Write-Host "ERROR: Can not find Blender.exe" -ForegroundColor Red
    ShowBalloonTip "Can not find $fName" "Baking Daemon" "Error"
    if ($DEBUG -ne $true) {
        Exit 22
    }
}

# Add path to Blender.exe to Path system variable
BackupPath ($PSScriptRoot + "\backup-path.txt")
AppendToPath $blenderPath

# Select cloud baking folder and create symbolic link
[String]$bakingFolderCloud = SelectFolder  "Select the directory that you want to use as Baking folder"
#[string]$baseFolder = $MyInvocation.MyCommand.Path | Split-Path -Parent
[string]$bakingFolderLocal = $PSScriptRoot + "\" + $BAKING_FOLDER_NAME
Write-Host "Baking folder cloud: $bakingFolderCloud"
Write-Host "Baking folder local: $bakingFolderLocal"

try {
    $null = New-Item -ItemType SymbolicLink -Path $bakingFolderLocal -Target $bakingFolderCloud -Force -ErrorAction Stop
} catch {
    Write-Host "ERROR: Can not create a symbolic link to the baking folder" -ForegroundColor Red
}

if ($DEBUG -ne $true) {
    # Rename installer CMD file
    if ($cmdName -ne "") {
        $null = Rename-Item -Path "$cmdName" -NewName "$cmdName.bak"
    }

    # Create tasks to empty Yandex disk trash bin and to run Baking Daemon on Windows startup
    CreateSheduledTasks
}

Write-Host "Baking Daemon installed successfully" -ForegroundColor Green
Write-Host "You need to restart your computer to start Baking Daemon" -ForegroundColor Yellow
ShowBalloonTip "Installation completed" "Baking Daemon" "Info"

$form = New-Object System.Windows.Forms.Form
$form.Text = "Baking Daemon"
$form.minimumSize = New-Object System.Drawing.Size(300,150)
$form.maximumSize = New-Object System.Drawing.Size(300,150)
$form.AutoSize = $false
$form.StartPosition = 'CenterScreen'
$form.MinimizeBox = $false
$form.MaximizeBox = $false
$form.AutoScale = $false
$form.AutoSize = $false

$okButton = New-Object System.Windows.Forms.Button
$okButton.Location = New-Object System.Drawing.Point(75,70)
$okButton.Size = New-Object System.Drawing.Size(75,23)
$okButton.Text = "Yes"
$okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.AcceptButton = $okButton
$form.Controls.Add($okButton)

$cancelButton = New-Object System.Windows.Forms.Button
$cancelButton.Location = New-Object System.Drawing.Point(150,70)
$cancelButton.Size = New-Object System.Drawing.Size(75,23)
$cancelButton.Text = "No"
$cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.CancelButton = $cancelButton
$form.Controls.Add($cancelButton)

$label = New-Object System.Windows.Forms.Label
$label.Location = New-Object System.Drawing.Point(10,20)
$label.Size = New-Object System.Drawing.Size(280,20)
$label.AutoSize = $false
$label.Text = "Do you want to restart your computer right now?"
$form.Controls.Add($label)

$form.Topmost = $true
$result = $form.ShowDialog()

if ($result -eq [System.Windows.Forms.DialogResult]::OK)
{
    Write-Host "YES. Restarting..."
    # Restart computer
    Start-Sleep -Seconds 10
    Restart-Computer
} else {
    Write-Host "NO. Plaese, restart your computer later"
    Exit 0
}

<#
# Start Baking service
Write-Host "Starting Baking Daemon..." -ForegroundColor Yellow
Start-Process -FilePath "powershell.exe" -ArgumentList @("-NoExit","-File $PSScriptRoot\baking_daemon.ps1")
#>
