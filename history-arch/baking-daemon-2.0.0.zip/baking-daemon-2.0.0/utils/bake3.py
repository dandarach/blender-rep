import bpy
import os

bpy.ops.teamatical.bake_and_save_shadows()
bpy.ops.teamatical.save_obj()
bpy.ops.wm.quit_blender
