# Empty Yandex disk trash bin

Add-Type -AssemblyName System.Windows.Forms

function ShowBalloonTip([String]$text = "", [String]$title = "Baking Daemon", [String]$icon = "Info", [Int]$showtime = 5000) {
    # $icon can be 'None','Info','Warning','Error'
    $global:balloon = New-Object System.Windows.Forms.NotifyIcon
    $path = (Get-Process -id $pid).Path
    $balloon.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($path)
    $balloon.BalloonTipIcon = $icon
    $balloon.BalloonTipText = $text
    $balloon.BalloonTipTitle = $title
    $balloon.Visible = $true
    $balloon.ShowBalloonTip($showTime)
}

Write-Host "Cleaning Yandex disk Baking folder" -ForegroundColor Yellow
ShowBalloonTip "Cleaning Yandex disk Baking folder" "Baking Daemon" "Info"
Invoke-WebRequest -Uri https://cloud-api.yandex.net/v1/disk/trash/resources/?path= -Headers @{Authorization = "OAuth AQAAAABOR3OMAAhJBH5ZAB78xUxCnabmzL8cBMk"} -Method DELETE