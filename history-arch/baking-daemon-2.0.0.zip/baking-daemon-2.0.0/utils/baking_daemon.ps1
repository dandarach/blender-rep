<#
    .SYNOPSIS
    Bakes shadows in Blender and exports OBJ + PNG

    .DESCRIPTION
    Wathching *.blend files in specified folder and baking shadows

    .PARAMETER TelegramMessaging
    Send messages via Telegram flag

    .EXAMPLE
    PowerShell.exe -NoExit -File "D:\work\_utils\BlenderAutomation3\baking-daemon\baking_daemon.ps1"
  
    .NOTES
    Version:        2.0.0
    Author:         Teamatical Inc.
    Creation Date:  22 oct 2019
    Modified Date:  22 jan 2023
    Link:           https://www.teamatical.com
#>


[CmdletBinding()]
Param()

[String]$Global:BakingFolder = $PSScriptRoot + "\baking-files"
[String]$LogFile = "$BakingFolder\baking.log"
[String]$BlenderLog = "$BakingFolder\blender.log"
[Boolean]$TelegramMessaging = $true
[Boolean]$WatchInSubfolders = $false


### Try to bake shadows and remove .blend file when baking complete
function TryToBake([String]$File) {
    # Check if baking process already started or if there are no BLEND files in baking folder
    if ((IsFileExist "blend_baking") -or !($IsBlendFileExist = IsFileExist "blend")) {
        #AppendToLog "WARNING: Can not find BLEND file" "Yellow"
        return
    }

    [psobject]$File = Get-ChildItem -Path $BakingFolder -Filter "*.blend" | Select-Object -First 1
    # Change file extension
    Rename-Item -Path $BakingFolder\$File -NewName ($File.Basename + ".blend_baking")

    [DateTime]$StartDate = (GET-DATE)
    [String]$LogLine = "$StartDate - Start baking new file: $File"
    AppendToLog $LogLine "Yellow"
    SendTelegramMessage $LogLine

    # Start baking job
    [String]$BlenderFile = ("$BakingFolder\" + $File + "_baking")
    AppendToLog "Start Blender process: $BlenderFile"
    Start-Process -WindowStyle Hidden -FilePath "blender.exe" -ArgumentList "--background `"$BlenderFile`"","--python $PSScriptRoot\bake3.py" -Wait -RedirectStandardOutput $BlenderLog

    # Remove processed BLEND file
    Remove-Item -Path $BlenderFile
    [DateTime]$EndDate = (GET-DATE)
    [String]$elapsed = ($EndDate - $StartDate).ToString()
    [String]$LogLine = "$EndDate - Stop baking. Time taken to process $File" + ": $elapsed"
    AppendToLog $LogLine "Green"
    SendTelegramMessage $LogLine
}

function IsFileExist([String]$Ext) {
    return Test-Path -PathType Leaf -Path "$BakingFolder\*.$Ext"
}

### Simple Logger
function AppendToLog([String]$Text = "", [String]$TextColor = "White") {
    Write-Host "$Text" -ForegroundColor $TextColor
    Add-content $LogFile -value $Text
}

### Send message from Teamatical Telegram Bot
function SendTelegramMessage([String]$Text = "default message") {
    if (!$TelegramMessaging) { return }
    # TeamaticalBot
    [String]$Token = "907282781:AAFYlbsJKRneHOnOogaJBxtJF1qEAzN7FeQ"
    # In TeamaticalBakingGroup
	[String]$ChatID = "-398166029"
	[String]$Proxy = "http://peremoga.ga:8083"

    Write-Host "Sendind Telegram Message..." -ForegroundColor Gray
    [String]$URL = "https://api.telegram.org/bot$Token/sendMessage?chat_id=$ChatID&text=$Text"
	$Payload = @{
		"parse_mode" = "HTML";
		"disable_web_page_preview" = "True";
	}
    try {
	    $request = Invoke-WebRequest `
            -Uri $URL `
            -UseBasicParsing `
            -Method Post `
            -ContentType "application/json;charset=utf-8" `
            -Body (ConvertTo-Json -Compress -InputObject $payload) `
            -DisableKeepAlive `
            -TimeoutSec 20
    } catch {
        "$_"
        Write-Error "Telegram can not send message"
    }
}


###================================================================================###
###================================================================================###
Write-Host "*** Baking Automation Script v3.2.1 ***" -ForegroundColor Green
AppendToLog "Current working directory: $PSScriptRoot" "Yellow"
AppendToLog "Baking folder: $BakingFolder" "Yellow"

# Remove old Log files
Remove-Item -Path $LogFile -Force -ErrorAction SilentlyContinue
Remove-Item -Path $BlenderLog -Force -ErrorAction SilentlyContinue

# Define actions after .blend file added to the Baking folder
[psobject]$Filewatcher = New-Object System.IO.FileSystemWatcher
$Filewatcher.Path = $BakingFolder
$Filewatcher.Filter = "*.blend*"
$Filewatcher.IncludeSubdirectories = $WatchInSubfolders
$Filewatcher.EnableRaisingEvents = $true  
    
$FileAction = { 
    [psobject]$EventDetails = $event.SourceEventArgs
    [String]$FileName = $EventDetails.Name
    [String]$FullPath = $EventDetails.FullPath
    [String]$OldFullPath = $EventDetails.OldFullPath
    [String]$OldName = $EventDetails.OldName
    [String]$ChangeType = $EventDetails.ChangeType
    [String]$TimeStamp = $event.TimeGenerated

    <#
    Let's compose a message
    $text = "{0} was {1} at {2}" -f $FullPath, $ChangeType, $Timestamp
    AppendToLog ""
    AppendToLog $text "DarkYellow"
    #>

    switch ($ChangeType)
    {
        "Created" {
            AppendToLog "$TimeStamp - New .blend file was found: $FullPath" "Gray"
            TryToBake
        }
        "Deleted" {
            AppendToLog "$TimeStamp - Removed file: $FileName" "Gray"
            TryToBake
        }
        default {
            # Any unhandled change types surface here:
            Write-Host $_ -ForegroundColor Red -BackgroundColor White
        }
    }
}

# Remove old event listeners
#Get-Event -SourceIdentifier "FileSystemWatcher.Created" | Remove-Event
Unregister-Event -SourceIdentifier "FileSystemWatcher.Created" -Force -ErrorAction SilentlyContinue
Unregister-Event -SourceIdentifier "FileSystemWatcher.Deleted" -Force -ErrorAction SilentlyContinue

# Add new event listeners
$addBlenderFile = Register-ObjectEvent $Filewatcher "Created" -SourceIdentifier "FileSystemWatcher.Created" -Action $FileAction
$removeBlenderFile = Register-ObjectEvent $Filewatcher "Deleted" -SourceIdentifier "FileSystemWatcher.Deleted" -Action $FileAction

AppendToLog "Start watching" "Yellow"

# Try to bake the first file
# Check if abnormal script restart
if (IsFileExist "blend_baking") {
    [psobject]$File = Get-ChildItem -Path $BakingFolder -Filter "*.blend_baking" | Select-Object -First 1
    Rename-Item -Path $BakingFolder\$File -newname ($File.Basename + ".blend")
    [String]$LogLine = "WARNING: $TimeStamp - Something was wrong. Rebaking file: $File"
    AppendToLog $LogLine "Red"
    SendTelegramMessage $LogLine
}

TryToBake
