import bpy
import os
import datetime

filepath = str(os.path.dirname(bpy.data.filepath))
filename = os.path.splitext(bpy.data.filepath)[0]
fileext= os.path.splitext(bpy.data.filepath)[1]

logfile = open(filepath + "/" + "baking.log", 'a')
timestamp = datetime.datetime.now()
logfile.write("---------------------------------------------------------\n")
logfile.write("Baking start " + filename + fileext + " at " + timestamp.strftime("%d/%m/%Y %H:%M:%S") + "\n")

bpy.ops.teamatical.bake_and_save_shadows()

timestamp = datetime.datetime.now()
logfile.write("Baking end at " + timestamp.strftime("%d/%m/%Y %H:%M:%S") + "\n\n")
logfile.close()

bpy.ops.teamatical.save_obj()

bpy.ops.wm.quit_blender()